package com.example.librarydemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class UpdateBook extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_book);
    }
}
